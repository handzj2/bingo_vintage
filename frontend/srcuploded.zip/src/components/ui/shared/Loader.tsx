export default function Loader() {
  return <div>Loading...</div>
}