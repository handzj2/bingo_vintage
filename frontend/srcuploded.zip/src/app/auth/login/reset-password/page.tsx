export default function ResetPasswordPage() {
  return (
    <div>
      <h1>Reset Password</h1>
      <p>Reset password form will go here.</p>
    </div>
  )
}