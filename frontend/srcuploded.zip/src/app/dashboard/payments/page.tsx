import PaymentsPage from "@/features/payments/PaymentsPage";

export default function Page() {
  return <PaymentsPage />;
}